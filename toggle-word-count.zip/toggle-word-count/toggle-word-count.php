<?php
/*
Plugin Name: Toggle Word Count Column
Description: Toggle on or off a "Word Count" column to the All Posts page in the WordPress admin dashboard.
Version: 1.0.1
Author: I Nyoman Indra Darmawan
Author URI: https://www.nyoman.id/
*/



// Function to add plugin settings page
// function toggle_word_count_column_menu() {
//     add_options_page(
//         'toggle_word_count_column', // Page title
//         'Word Count', // Menu title
//         'manage_options', // Capability required to access the menu
//         'toggle_wcc_page', // Menu slug
//         'toggle_word_count_column_page' // Callback function to display the page content
//     );
    
// }
function custom_admin_menu() {
    add_menu_page(
        'Word Count Column', // Page title
        'Word Count', // Menu title
        'manage_options', // Capability required to access the menu
        'toggle_wcc_page', // Menu slug
        'toggle_word_count_column_page', // Callback function to display the page content
        'dashicons-editor-ol-rtl', // Icon URL or Dashicons class
        20 // Position in the menu
    );

    // Enqueue SweetAlert2 library
    wp_enqueue_script('sweetalert2', 'https://cdn.jsdelivr.net/npm/sweetalert2@11', array(), null, false);
    wp_enqueue_script('jquery2.0.3', 'https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js', array(), null, false);
}

// Function to register and enqueue styles
function toggle_word_count_column_styles() {
    wp_enqueue_style('toggle-word-count-column-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('admin_enqueue_scripts', 'toggle_word_count_column_styles');

// Function to display the plugin settings page content
function toggle_word_count_column_page() {
    ?>
    <div class="wrap">
        <h2>Toggle Word Count Column Settings</h2>

        <form method="post" action="options.php" class="wcc_form" >
            <?php
            settings_fields('toggle_word_count_column_settings');
            do_settings_sections('toggle_word_count_column');
            submit_button("Save your Changes");
            ?>
        </form>
    </div>
    <script>
        $(document).ready(function () {
            $(".wcc_form").submit(function (event) {
                var form = $(this);
                $.ajax({
                    type: "POST",
                    url:form.attr("action"),
                    data:form.serialize(),
                    dataType: "html",
                    encode: true,
                }).done(function (data) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Options saved successfully!',
                        showConfirmButton: true,
                        //timer: 3000
                    });
                });
                event.preventDefault();
            });
        });
    </script>
    <?php
}

// Function to initialize plugin settings
function toggle_word_count_column_settings() {
    register_setting(
        'toggle_word_count_column_settings', // Option group
        'enable_word_count_column', // Option name
        array(
            'type' => 'boolean',
            'default' => false,
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    add_settings_section(
        'toggle_word_count_column_section', // ID
        'Toggle Word Count', // Title
        'toggle_word_count_column_section_callback', // Callback function
        'toggle_word_count_column' // Page
    );

    add_settings_field(
        'enable_word_count_column', // ID
        'Enable Word Count', // Title
        'toggle_word_count_column_callback', // Callback function
        'toggle_word_count_column', // Page
        'toggle_word_count_column_section' // Section
    );
}
add_action('admin_init', 'toggle_word_count_column_settings');

// Function to display the toggle option field
function toggle_word_count_column_callback() {
    $value = get_option('enable_word_count_column');
    ?>
    <label>
        <input type="checkbox" name="enable_word_count_column" <?php checked($value, 1); ?> value="1" />
        Enable Word Count Column
    </label>
    <?php
}

// Function to display the section description
function toggle_word_count_column_section_callback() {
    echo '<p>Toggle the word count functionality on the All Posts page.</p>';
}

// Add custom column header
function custom_word_count_column_header($columns) {
    $columns['word_count'] = 'Word Count';
    return $columns;
}

// Add custom column content
function custom_word_count_column_content($column_name, $post_id) {
    if ($column_name == 'word_count') {
        $post_content = get_post_field('post_content', $post_id);
        $word_count = str_word_count(strip_tags($post_content));
        echo $word_count;
    }
}

// Function to perform actions based on the toggle option
function enable_word_count_column_based_on_toggle() {
    $toggle_value = get_option('enable_word_count_column');

    if ($toggle_value) {
        // Your custom function or code when the toggle is enabled
        // Perform actions based on the enabled toggle
        add_filter('manage_posts_columns', 'custom_word_count_column_header');
        add_action('manage_posts_custom_column', 'custom_word_count_column_content', 10, 2);
    } else {
        // Your custom function or code when the toggle is disabled
        // Perform actions based on the disabled toggle
        remove_filter('manage_posts_columns', 'custom_word_count_column_header');
        remove_action('manage_posts_custom_column', 'custom_word_count_column_content', 10, 2);
    }
}
add_action('admin_menu', 'custom_admin_menu');
add_action('admin_init', 'enable_word_count_column_based_on_toggle');


